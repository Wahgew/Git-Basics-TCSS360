import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
class FrequencyNode implements Comparable<FrequencyNode>{
    public Character character;
    public Integer count;
    public FrequencyNode(Character character, Integer count) {
        this.character = character;
        this.count = count;
    }
    public int compareTo(FrequencyNode other) {
        return (character.compareTo(other.character));
    }
    public String toString() {
        return character + ":" + count;
    }
}
class HuffmanNode implements Comparable<HuffmanNode>{
    public Character character;
    public Integer weight;
    public HuffmanNode left;
    public HuffmanNode right;
    public String word;
    public HuffmanNode(Character character, Integer weight) {
        this.character = character;
        this.weight = weight;
    }
    public HuffmanNode(HuffmanNode left, HuffmanNode right) {
        this.left = left;
        this.right = right;
        this.weight = left.weight + right.weight;
    }
    public HuffmanNode(String word, Integer wt) {
        this.word = word;
        this.weight = wt;
    }
    public int compareTo(HuffmanNode other) {
        return weight.compareTo(other.weight);
    }
    public String toString() {
        return word + ":" + weight;
    }
}
class CodeNode implements Comparable<CodeNode>{
    public Character character;
    public String code;
    public CodeNode(Character character, String code) {
        this.character = character;
        this.code = code;
    }
    public int compareTo(CodeNode other) {
        return (character.compareTo(other.character));
    }
    public String toString() {
        return character + ":" + code;
    }
}
public class HuffmanEncoder {
    protected String inputFileName;
    protected String outputFileName;
    protected String codesFileName;
    protected BookReader book;
    protected boolean wordCodes = true;
    protected MyHashTable<String, Integer> frequenciesHash;
    protected MyHashTable<String, String> codesHash;
    protected HuffmanNode huffmanTree;
    public byte[] encodedText;
    public HuffmanEncoder() throws IOException{
        inputFileName = "./WarAndPeace.txt";
        outputFileName = "./WarAndPeace-compressed.bin";
        codesFileName = "./WarAndPeace-code.txt";

        book = new BookReader(inputFileName);
        frequenciesHash = new MyHashTable<>(32768);
        codesHash = new MyHashTable<>(32768);
        huffmanTree = null;
        encodedText = null;

        countFrequency();
        buildTree();
        encode();
        writeFiles();
    }
    protected void countFrequency() {
        long start = System.currentTimeMillis();
        String text = book.book;
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            String key = String.valueOf(ch);
            if (wordCodes && Character.isWhitespace(ch)) {
                key = " ";
            }
            Integer count = frequenciesHash.get(key);
            if (count != null) {
                frequenciesHash.put(key, count + 1);
            } else {
                frequenciesHash.put(key, 1);
            }
        }
        long end = System.currentTimeMillis();
        System.out.println("\nCounting frequencies of characters... " + frequenciesHash.size() +
                " unique characters found in " + (end - start) + " milliseconds.");
    }
    protected void buildTree() {
        long start = System.currentTimeMillis();
        MyPriorityQueue<HuffmanNode> priorityQueue = new MyPriorityQueue<>();
        // Iterate through all keys in the frequencies hash table
//        for (int i = 0; i < frequenciesHash.capacity; i++) {
//            if (frequenciesHash.keyBuckets[i] != null && frequenciesHash.valueBuckets[i] != null) {
//                String key = (String) frequenciesHash.keyBuckets[i];
//                Integer frequency = (Integer) frequenciesHash.valueBuckets[i]; // Cast to Integer
//                priorityQueue.insert(new HuffmanNode(key, frequency));
//            }
//        }
        // Construct the Huffman tree using the priority queue
        while (priorityQueue.size() > 1) {
            HuffmanNode left = priorityQueue.removeMin();
            HuffmanNode right = priorityQueue.removeMin();
            HuffmanNode parent = new HuffmanNode('\0', left.weight + right.weight);
            parent.left = left;
            parent.right = right;
            priorityQueue.insert(parent);
        }
        // Retrieve the Huffman tree root
        huffmanTree = priorityQueue.removeMin();
        // Extract codes from the Huffman tree
        extractCodes(huffmanTree, "");
        long endTime = System.currentTimeMillis();
        System.out.println("\nBuilding a Huffman tree and reading codes... in "
                + (endTime - start) + " milliseconds.");
    }
    protected void extractCodes(HuffmanNode node, String code) {
        if (node != null) {
            if (node.character != '\0') {
                codesHash.put(node.word, code);
            }
            extractCodes(node.left, code + "0");
            extractCodes(node.right, code + "1");
        }
    }
    protected void encode() {
        long start = System.currentTimeMillis();
        StringBuilder textCode = new StringBuilder();
        String bookText = book.book;
        for (int i = 0; i < bookText.length(); i++) {
            String ch = String.valueOf(bookText.charAt(i));
            String code = codesHash.get(ch);
            if (code != null) {
                textCode.append(code);
            }
        }
        String encodedString = textCode.toString();
        encodedText = new byte[encodedString.length() / 8 + 1];
        int index = 0;
        for (int i = 0; i < encodedString.length(); i += 8) {
            String byteStr = encodedString.substring(i, Math.min(i + 8, encodedString.length()));
            int value = Integer.parseInt(byteStr, 2);
            encodedText[index] = (byte) value;
            index++;
        }
        long end = System.currentTimeMillis();
        System.out.println("\nEncoding message... in " + (end - start) + " milliseconds.");
    }
    private void writeFiles() {
        long start = System.currentTimeMillis();
        try (FileOutputStream compressedFileOutputStream = new FileOutputStream(outputFileName);
             PrintWriter codesPrintWriter = new PrintWriter(codesFileName)) {
            compressedFileOutputStream.write(encodedText);
            // Iterate through all keys in the codes hash table
            for (int i = 0; i < codesHash.capacity; i++) {
                if (codesHash.keyBuckets[i] != null) {
                    String key = codesHash.keyBuckets[i];
                    String code = codesHash.get(key);
                    codesPrintWriter.println(key + ":" + code);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        long endTime = System.currentTimeMillis();
        System.out.println("\nWriting compressed file... " + encodedText.length +
                " bytes written in " + (endTime - start) + " milliseconds.");
    }
}
