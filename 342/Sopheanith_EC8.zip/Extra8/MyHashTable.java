public class MyHashTable<Key extends Comparable<Key>, Value> {
    protected Integer capacity;
    protected Key[] keyBuckets;
    protected Value[] valueBuckets;
    protected Integer size;
    public MyArrayList keys;
    public Integer comparisons;
    public Integer maxProbe;

    private final boolean chaining;

    private MyArrayList<KeyValuePair>[] chainBuckets;


    public MyHashTable(boolean chaining) {
        this.chaining = false;
    }

    public MyHashTable(Integer capacity, boolean chaining) {
        this.capacity = capacity;
        this.chaining = chaining;
        this.keyBuckets = (Key[]) new Comparable[capacity];
        this.valueBuckets = (Value[]) new Object[capacity];
        this.size = 0;
        this.comparisons = 0;
        this.keys = new MyArrayList<>();
        this.chainBuckets = new MyArrayList[capacity];
        this.maxProbe = 0;
    }

    private int hash(Object key) {
        // Use the hashCode method of the key
        int hashCode = key.hashCode();
        // Map the hash code to an index within the range of 0 to capacity - 1
        int index = Math.abs(hashCode) % capacity;
        return index;
    }

    public Value get(Key key) {
        int index = hash(key);
        MyArrayList<KeyValuePair> buckets = chainBuckets[index];
        int probes = 1;
        if (buckets != null) {
            for (int i = 0; i < buckets.size(); i++) {
                probes++;
                KeyValuePair pair = buckets.get(i);
                if (pair.key.equals(key)) {
                    return pair.value;
                }
                if (probes > maxProbe) {
                    maxProbe = probes;

                }
            }
        }
        return null;
    }
    // maintain probing and chaning
    public void put(Key key, Value value) {
        // Calculate the hash index for the key
        int index = hash(key);
        // Store the value of comparisons before any comparisons are made
        int beforeComparisons = comparisons;
        // Increment comparisons for the current operation
        comparisons++;
        // If chaining is enabled
        if (chaining) {
            // Create a new key-value pair
            KeyValuePair newPair = new KeyValuePair();
            newPair.key = key;
            newPair.value = value;
            // Access the list of key-value pairs at the hash index
            MyArrayList<KeyValuePair> bucket = findOrCreateBucket(key);
            // If the bucket is null, create a new one and add the key-value pair
            if (bucket == null) {
                bucket = new MyArrayList<>();
                chainBuckets[index] = bucket;
                bucket.insert(newPair, 0);
                keys.insert(key, keys.size());
                size++;
                maxProbe = Math.max(maxProbe, comparisons - beforeComparisons);
                return;
            }
            // Iterate through the bucket to find the key
            for (int i = 0; i < bucket.size(); i++) {
                comparisons++;
                if (key.equals(bucket.get(i).key)) {
                    // Update the value if the key already exists
                    bucket.get(i).value = value;
                    maxProbe = Math.max(maxProbe, comparisons - beforeComparisons);
                    return;
                }
            }
            // Insert the new key-value pair into the bucket
            bucket.insert(newPair, bucket.size());
            size++;
            maxProbe = Math.max(maxProbe, comparisons - beforeComparisons);
            return;
        }
        // If chaining is not enabled, use linear probing
        while (keyBuckets[index] != null && !keyBuckets[index].equals(key)) {
            index = (index + 1) % capacity;
            comparisons++;
        }
        // If the key is not found, insert it into the hash table
        if (keyBuckets[index] == null) {
            size++;
            keys.insert(key, keys.size());
        }
        // Update maxProbe if necessary
        maxProbe = Math.max(maxProbe, comparisons - beforeComparisons);

        // Insert the key and value into their respective arrays
        keyBuckets[index] = key;
        valueBuckets[index] = value;
    }

    public MyArrayList<KeyValuePair> findOrCreateBucket(Key key) {
        // Calculate the hash index for the key
        int index = hash(key);

        // Access the list of key-value pairs stored at the hash index
        MyArrayList<KeyValuePair> bucket = chainBuckets[index];

        // If the list is not found, create a new one and add it to the hash table
        if (bucket == null) {
            bucket = new MyArrayList<>(); // Create a new empty list
            chainBuckets[index] = bucket; // Add the new list to the hash table
        }

        // Return the list of key-value pairs
        return bucket;
    }

    public Integer size() {
        return size;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        boolean first = true; // Flag to handle comma placement

        // Append each non-null key-value pair to the StringBuilder in the required format
        sb.append("[");
        for (int i = 0; i < chainBuckets.length; i++) {
            MyArrayList<KeyValuePair> bucket = chainBuckets[i];
            if (bucket != null) {
                for (int j = 0; j < bucket.size(); j++) {
                    KeyValuePair pair = bucket.get(j);
                    if (!first) {
                        sb.append(", "); // Add comma separator if not the first element
                    } else {
                        first = false;
                    }
                    sb.append(pair.key);
                    sb.append(":");
                    sb.append(pair.value);
                }
            }
        }
        sb.append("]");

        // Return the final string representation
        return sb.toString();
    }


    protected class KeyValuePair implements Comparable<KeyValuePair> {
        public Key key;
        public Value value;


        public String toString() {
            return key + ":" + value;
        }
        @Override
        public int compareTo(KeyValuePair o) {
            return 0;
        }
    }
}