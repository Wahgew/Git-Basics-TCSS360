

public class UniqueWords {
    //add size and comparsions
    public BookReader book;
    public MyArrayList<String> alOfUniqueWords;
    public MyLinkedList<String> llOfUniqueWords;
    //public MyOrderedList<String> olOfUniqueWords;
    public MyBinarySearchTree<String> bstOfUniqueWords;

    //public MyHashTable<String, String> hashOfUniqueWords;

    public MyHashTable<String,String> chainHashOfUniqueWords;
    public UniqueWords() {
        // this.book = new BookReader("test.txt");
        this.book = new BookReader("WarAndPeace.txt");
        this.alOfUniqueWords = new MyArrayList<>();
        this.llOfUniqueWords = new MyLinkedList<>();
        //this.olOfUniqueWords = new MyOrderedList<>();
        //this.bstOfUniqueWords = new MyBinarySearchTree<>();
        this.chainHashOfUniqueWords = new MyHashTable<>(32768, true);
    }
//    public void addUniqueWordsToLinkedList() {
//        String file = book.words.first();
//        long time;
//        long start = System.currentTimeMillis();
//        long duration = System.currentTimeMillis() - start;
//        outputDuration("Adding unique words to a linked list", duration);
//        while (file != null) {
//            if (!llOfUniqueWords.contains(book.words.current())) {
//                llOfUniqueWords.addBefore(book.words.current());
//            }
//            file = book.words.next();
//        }
//        System.out.println(llOfUniqueWords.size() + " unique words were found.");
//        System.out.println(llOfUniqueWords.comparisons + " comparisons were made.");
//
//        start = System.currentTimeMillis();
//        llOfUniqueWords.sort();
//        duration = System.currentTimeMillis() - start;
//        outputDuration("Bubble sorting linked list", duration);
//    }
//    public void addUniqueWordsToBST() {
//        long start = System.currentTimeMillis();
//        long duration;
//        // Iterate over the list of words in book
//        String word = book.words.first();
//        while (word != null) {
//            // Check if the word is already in the binary search tree
//            if (bstOfUniqueWords.find(word) == null) {
//                // If the word is not in the binary search tree, add it
//                bstOfUniqueWords.add(word);
//            }
//            word = book.words.next();
//        }
//
//        // Output the runtime for adding unique words to the BST
//        duration = System.currentTimeMillis() - start;
//        outputDuration("Adding unique words to a binary search tree", duration);
//
//        // Output the number of unique words
//        System.out.println(bstOfUniqueWords.size() + " unique words were found.");
//        // Output the number of comparisons made
//        System.out.println(bstOfUniqueWords.comparisons + " comparisons were made.");
//
//        // Time the sorting operation (not needed for BST)
//        start = System.currentTimeMillis();
//        // No sorting needed for BST
//        duration = System.currentTimeMillis() - start;
//
//        // Output the runtime for sorting the BST (which is not applicable)
//        outputDuration("Sorting binary search tree (not applicable)", duration);
//    }

//    public void addUniqueWordsToHashTable() {
//        long start = System.currentTimeMillis();
//        long duration;
//        // Iterate over the list of words in book
//        String word = book.words.first();
//        while (word != null) {
//            // Check if the word is already in the binary search tree
//            if (hashOfUniqueWords.get(word) == null) {
//                // If the word is not in the binary search tree, add it
//                hashOfUniqueWords.put(word,word);
//            }
//            word = book.words.next();
//        }
//
//        // Output the runtime for adding unique words to the BST
//        duration = System.currentTimeMillis() - start;
//        outputDuration("Adding unique words to hash table", duration);
//
//        // Output the number of unique words
//        System.out.println(hashOfUniqueWords.size() + " unique words were found.");
//        // Output the number of comparisons made
//        System.out.println(hashOfUniqueWords.comparisons + " comparisons were made.");
//
//        System.out.println(hashOfUniqueWords.maxProbe);
//        // Time the sorting operation (not needed for BST)
//        start = System.currentTimeMillis();
//        // No sorting needed for BST
//        duration = System.currentTimeMillis() - start;
//
//        // Output the runtime for sorting the BST (which is not applicable)
//        outputDuration("Extracting the key-value pairs", duration);
//    }

    public void addUniqueWordsToHashTable2(){
        long start = System.currentTimeMillis();
        long duration;
        // Iterate over the list of words in book
        String word = book.words.first();
        while (word != null) {
            // Check if the word is already in the binary search tree
            if (chainHashOfUniqueWords.get(word) == null) {
                // If the word is not in the binary search tree, add it
                chainHashOfUniqueWords.put(word,word);
            }
            word = book.words.next();
        }
        // Output the runtime for adding unique words to the BST
        duration = System.currentTimeMillis() - start;
        outputDuration("Adding unique words to hash table", duration);

        // Output the number of unique words
        System.out.println(chainHashOfUniqueWords.size() + " unique words were found.");
        // Output the number of comparisons made
        System.out.println(chainHashOfUniqueWords.comparisons + " comparisons were made.");

        System.out.println(chainHashOfUniqueWords.maxProbe + " max chain");
        // Time the sorting operation (not needed for BST)
        start = System.currentTimeMillis();
        // No sorting needed for BST
        duration = System.currentTimeMillis() - start;

        // Output the runtime for sorting the BST (which is not applicable)
        outputDuration("Extracting the key-value pairs", duration);

    }

    private void outputDuration(String action, long duration) {
        System.out.print(action + "...");
        if (duration < 1000) {
            System.out.println(" in " + duration + " milliseconds.");
        } else {
            long pre = duration / 1000;
            long post = duration % 1000;
            System.out.println(" in " + pre + "." + post + " seconds.");
        }
    }
    /*

    public void addUniqueWordsToArrayList() {
        String file = book.words.first();
        long start = System.currentTimeMillis();
        long duration = System.currentTimeMillis() - start;

        while (file != null) {
            if (!alOfUniqueWords.contains(book.words.current())) {
                alOfUniqueWords.insert(book.words.current(), alOfUniqueWords.size());
                //System.out.print(alOfUniqueWords.size());
            }
            file = book.words.next();
        }
        System.out.println(alOfUniqueWords.size() + " unique words were found.");
        System.out.println(alOfUniqueWords.comparisons + " comparisons were made.");
        start = System.currentTimeMillis();
        alOfUniqueWords.sort();
        duration = System.currentTimeMillis() - start;
        outputDuration("Sorting array list of unique words", duration);
    }
    public void addUniqueWordsToOrderedList() {
        String file = book.words.first();
        long start = System.currentTimeMillis();

        while (file != null) {
            // Binary search to check if the word is already in the ordered list
            boolean index = olOfUniqueWords.binarySearch(book.words.current());

            if (!index) {
                // Word not found, add it to the list
                olOfUniqueWords.add(book.words.current());
            }
            file = book.words.next();
        }

        long duration = System.currentTimeMillis() - start;
        outputDuration(olOfUniqueWords.size() + " unique words were added to the ordered list", duration);

        System.out.println(olOfUniqueWords.size() + " unique words were found.");
        System.out.println(olOfUniqueWords.comparisons + " comparisons were made.");

        // Sorting the ordered list (removed the incorrect binarySearch call)
        start = System.currentTimeMillis();
        duration = System.currentTimeMillis() - start;
        outputDuration("Sorting ordered list of unique words", duration);
    }
     */

}