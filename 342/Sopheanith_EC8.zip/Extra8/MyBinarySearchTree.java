public class MyBinarySearchTree<Type extends Comparable<Type>> {

    public Node root;
    public int size;
    public long comparisons;

    public MyBinarySearchTree() {
        this.root = null;
        this.size = 0;
        this.comparisons = 0;
    }

    // Add an item to the binary search tree
    public void add(Type item) {
        root = add(root, item);
    }

    private Node add(Node subTree, Type item) {
        if (subTree == null) {
            size++;
            return new Node(item);
        }

        int result = item.compareTo(subTree.item);
        if (result < 0) {
            subTree.left = add(subTree.left, item);
        } else {
            subTree.right = add(subTree.right, item);
        }

        updateHeight(subTree);
        return subTree;
    }

    // Remove an item from the binary search tree
    public void remove(Type item) {
        root = remove(root, item);
    }

    protected Node remove(Node subTree, Type item) {
        if (subTree == null) {
            return null;
        } else if (item.equals(subTree.item)) {
            if (subTree.left == null && subTree.right == null) {
                size--;
                return null;
            } else if (subTree.left == null) {
                size--;
                return subTree.right;
            } else if (subTree.right == null) {
                size--;
                return subTree.left;
            } else {
                Node smallestParent = subTree;
                Node smallest = subTree.right;
                while (smallest.left != null) {
                    smallestParent = smallest;
                    smallest = smallest.left;
                }
                subTree.item = smallest.item;
                if (smallestParent == subTree) {
                    smallestParent.right = smallest.right;
                } else {
                    smallestParent.left = smallest.right;
                }
                size--;
                updateHeight(subTree);
                return subTree;
            }
        } else if (item.compareTo(subTree.item) < 0) {
            subTree.left = remove(subTree.left, item);
        } else {
            subTree.right = remove(subTree.right, item);
        }

        updateHeight(subTree);
        return subTree;
    }

    // Find an item in the binary search tree
    public Type find(Type item) {
        return find(root, item);
    }

    private Type find(Node subTree, Type item) {
        if (subTree == null) {
            comparisons++;
            return null;
        }
        int result = item.compareTo(subTree.item);
        comparisons++;
        if (result < 0) {
            return find(subTree.left, item);
        } else if (result > 0) {
            return find(subTree.right, item);
        } else {
            return subTree.item;
        }
    }

    // Get the height of the binary search tree
    public int height() {
        return (root == null) ? -1 : root.height;
    }

    // Get the size of the binary search tree
    public int size() {
        return size;
    }

    // Check if the binary search tree is empty
    public boolean isEmpty() {
        return size == 0;
    }

    // Update the height of a node
    private void updateHeight(Node node) {
        if (node != null) {
            int leftHeight = (node.left == null) ? -1 : node.left.height;
            int rightHeight = (node.right == null) ? -1 : node.right.height;
            node.height = Math.max(leftHeight, rightHeight) + 1;
        }
    }

    // Convert the binary search tree to a string representation
    public String toString() {
        StringBuilder sb = new StringBuilder("[");
        toString(root, sb);
        sb.append("]");
        return sb.toString();
    }

    private void toString(Node subTree, StringBuilder sb) {
        if (subTree == null) {
            return;
        }
        if (subTree.left != null) {
            toString(subTree.left, sb);
            sb.append(", ");
        }
        sb.append(subTree);
        if (subTree.right != null) {
            sb.append(", ");
            toString(subTree.right, sb);
        }
    }

    // Node class representing a node in the binary search tree
    protected class Node {
        private Type item;
        private Node left;
        private Node right;
        public int height;

        public Node(Type item) {
            this.item = item;
            this.left = null;
            this.right = null;
            this.height = 0;
        }

        public String toString() {
            return item + ":H" + height;
        }
    }
}

